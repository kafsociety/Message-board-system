<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>修改留言</title>
	  <link rel="stylesheet" href="css/style.css">
</head>
<style type="text/css">
body {
    background-image: url( "登录.jpg");
	background-attachment: fixed;
	background-repeat: no-repeat;
	
	left:0px; top:0px; width:100%; height:100%";
}
.table{border-radius: 8px;border:1px }
			.main-container{
		width: 80%;
		margin:0 auto;
	}
.style1 {
    font-family: "微软雅黑";
}
body,td,th {
    color: #00529F;
}
</style>
<body>

 
  <p>
  <?php 
include 'conn.php'; 
error_reporting(0);
$id = $_GET['id'];
$result=mysqli_query($conn,"select * from message where id=".$id); 
while ($rs=mysqli_fetch_array($result)){ 

?>
  </p>
  </p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<table width="511" height="372" border="0" align="center" background="捕获.PNG"class="table">
	
  <tbody>
    <tr style="text-align: center">
      <td width="1005" height="368">
		  <FORM METHOD="POST" ACTION="postEdit.php"  style="text-align: center; font-family: '微软雅黑';" >
        <h1><strong>修改留言</strong></h1>
        <hr align="center">
        <p>
          <INPUT NAME="user" TYPE="text" placeholder="用 户" value="<?=$rs['user']?>"/>
        </p>
        <hr align="center" width="220" noshade="noshade">
        <p><br />
          <INPUT NAME="title" TYPE="text" placeholder="标 题" value="<?=$rs['title']?>"/>
        </p>
        <hr align="center" width="220" noshade="noshade">
       
          <INPUT NAME="content" TYPE="text" class="log" id="content" placeholder="内容" value="<?=$rs['content']?>"/>
          <p>
          <INPUT name="submit" TYPE="submit" class="btn" value="编辑"/>
      </p>
        <?php }?>
        </FORM></td>
    </tr>
  </tbody>
</table>
<p>&nbsp;</p>
</body>
</html>