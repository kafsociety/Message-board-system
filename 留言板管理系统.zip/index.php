<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>登录注册修改密码系统主页</title> 
	<link rel="stylesheet" href="css/style.css">
<style type="text/css">
body {
    background-image: url( "登录.jpg");
	background-size: 100%;
    background-repeat: no-repeat;
	background-attachment: fixed;
}
.style1 {
    font-family: "微软雅黑";
}
body,td,th {
    color: #006;
}
</style>
</head> 
<body>  
<form action="enter.php" method="post" style="text-align: center" onsubmit="return enter()"> 
   <p>&nbsp;</p>
   <p>&nbsp;</p>
   <p class="style1"><strong style="font-size: 36px">登录</strong></p>
   <p>&nbsp;</p>
   <p>
     <input name="username" type="text" class="login-form" id="username" placeholder="用户名">
  </p>
   <hr width="200">
  <input name="password" 
 type="password" class="login-form" id="password" placeholder="密码">
  <hr width="200">
   <P><input name='authcode' type="text" class="login-form"   placeholder="验证码" value=''/></p>
  <p class="login-form"><img id="captcha_img" border='1' src='./captcha.php?r=echo rand(); ?>' style="width:100px; height:30px" />
    <a href="javascript:void(0)" class="login" onclick="document.getElementById('captcha_img').src='./captcha.php?r='+Math.random()">换一个?</a></span></span></span></span></span></span></span></span><a href="javascript:void(0)" class="login" onclick="document.getElementById('captcha_img').src='./captcha.php?r='+Math.random()"></a></span>
  </p>
    </div>
 
					
							
 
  <p><br>
    <input type="submit" class="btn" value="登录">
  </p>
  <p>
    <input type="button" class="btn" onClick="register();" value="注册">
  </p>
  <p>&nbsp;</p>
</form> 
	
      
 

 
<script type="text/javascript"> 
 function enter() 
 { 
 var username=document.getElementById("username").value;//获取form中的用户名 
 var password=document.getElementById("password").value; 
 var regex=/^[/s]+$/;//声明一个判断用户名前后是否有空格的正则表达式 
 if(regex.test(username)||username.length==0)//判定用户名的是否前后有空格或者用户名是否为空 
 { 
 alert("用户名格式不对"); 
 return false; 
 } 
 if(regex.test(password)||password.length==0)//同上述内容 
 { 
 alert("密码格式不对"); 
 return false; 
 } 
 return true; 
 } 
 function register() 
 { 
 window.location.href="register.html";//跳转到注册页面 
	 
 } 
	
 </script> 
</body> 
</html> 
