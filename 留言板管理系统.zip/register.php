<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>注册用户</title> 
</head> 
<body> 
 <?php 
 session_start(); 
 $username=$_REQUEST["username"]; 
 $password=$_REQUEST["password"]; 
 
 $con=mysqli_connect("localhost","root",""); 
 if (!$con) { 
 die('数据库连接失败'.$mysqli_error()); 
 } 
 mysqli_select_db($con,"user_info"); 
 $dbusername=null; 
 $dbpassword=null; 
 $result=mysqli_query($con,"select * from user_info where username ='$username';"); 
 while ($row=mysqli_fetch_row($result)) { 
 $dbusername=$row["username"]; 
 $dbpassword=$row["password"]; 
 } 
 if(!is_null($dbusername)){ 
 ?> 
 <script type="text/javascript"> 
 alert("用户已存在"); 
 window.location.href="register.html"; 
 </script> 
 <?php 
 } 
 mysqli_query($con,"insert into user_info (username,password) values('$username','$password')") or die("存入数据库失败".mysqli_error()) ; 
 mysqli_close($con); 
 ?> 
 <script type="text/javascript"> 
 alert("注册成功"); 
 window.location.href="index.php"; 
 </script> 
 
 
</body> 
</html> 