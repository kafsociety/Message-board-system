<?php

echo "<script>alert('请先登录');location.href='list1.php';</script>";
exit;

?>