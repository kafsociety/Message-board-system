<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>无标题文档</title>
</head>
	

<body>
<?php 
$conn = mysqli_connect("localhost", "root", "","form") or die("数据库链接错误".mysqli_error()); 
//mysqli_select_db("form", $conn); 
mysqli_query($conn,"set names utf-8"); 
?> 
</body>
</html>