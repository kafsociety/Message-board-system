<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>添加留言</title>
	  <link rel="stylesheet" href="css/style.css">
	<style type="text/css">
body {
    background-image: url( "登录.jpg");
	background-attachment: fixed;
	background-repeat: no-repeat;
	
	left:0px; top:0px; width:100%; height:100%";
  
}
.table{border-radius: 8px;border:1px }
			.main-container{
		width: 80%;
		margin:0 auto;
	}
.style1 {
    font-family: "微软雅黑";
}
body,td,th {
    color: #00529F;
}
</style>
</head>

<body>
	<p>
	  <?php 
include 'conn.php'; 
if(isset($_POST['submit'])){ 
$sql="INSERT INTO message(id,user,title,content,lastdate) VALUES (NULL, '$_POST[user]', '$_POST[title]', '$_POST[content]', now())"; 
mysqli_query($conn,$sql); 
	
 
//页面跳转，实现方式为javascript 
$url = "list.php"; 
echo "<script language='javascript' type='text/javascript'>"; 
echo "window.location.href='$url'"; 
echo "</script>"; 
} 
?> 
</p>
	<p>&nbsp;</p>
	<p>&nbsp;</p>
<table width="511" height="372" border="0" align="center" background="捕获.PNG" class="table">
      <tbody>
        <tr style="text-align: center">
          <td width="1005" height="368"><FORM ACTION="add.php" METHOD="POST" name="addForm" style="text-align: center; font-family: '微软雅黑';" onsubmit="return checkPost();">
            <h1><strong>添加留言</strong></h1>
            <hr align="center">
            <p>
              <INPUT NAME="user" TYPE="text" placeholder="用 户" />
            </p>
            <hr align="center" width="220" noshade="noshade">
            <p>
              <INPUT NAME="title" TYPE="text" placeholder="标 题" />
            </p>
            <hr align="center" width="220" noshade="noshade">
            <INPUT NAME="content" TYPE="text" class="log" id="content" placeholder="内容" />
            <p>           
              <INPUT name="submit" TYPE="submit" class="btn" value="添加" />
            </p>
            <p>&nbsp;</p>
          </FORM></td>
        </tr>
      </tbody>
</table>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>
  <script type="text/javascript"> 
function checkPost(){ 
 
if(addForm.user.value==""){ 
alert("请输入用户名"); 
addForm.user.focus(); 
return false; 
} 
if(addForm.title.value.length<1){ 
alert("标题不能少于1个字符"); 
addForm.title.focus(); 
return false; 
} 
} 
    </script> 
</p>
</body>
</html>