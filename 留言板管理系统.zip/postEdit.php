<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>无标题文档</title>
</head>

<body>
	 <?php 

include 'conn.php'; 
	error_reporting(0);
$id = $_GET['id']; 


$sql="update message set user='$_GET[user]'  title='$rs[title]' content='$rs[content]' WHERE id =".$id;
mysqli_query($conn,$sql); 

?> 
<?php 
//页面跳转，实现方式为javascript 
$url = "list.php"; 
echo "<script language='javascript' type='text/javascript'>"; 
echo "window.location.href='$url'"; 
echo "</script>"; 
?>
</body>
</html>