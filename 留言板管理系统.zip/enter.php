<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>登录系统的后台执行过程</title> 
</head> 
<body> 
	<?php
 header("Content-Type:text/html;charset=utf-8");      //设置头部信息
  //isset()检测变量是否设置
  if(isset($_REQUEST['authcode'])){
    session_start();
    //strtolower()小写函数
    if(strtolower($_REQUEST['authcode'])== $_SESSION['authcode']){
      //跳转页面
      echo "<script language=\"javascript\">";
      echo "document.location=\"list.php\"";
      echo "</script>";
    }else{
      //提示以及跳转页面
      echo "<script language=\"javascript\">";
      echo "alert('验证码输入错误!');";
      echo "document.location=\"index.php\"";
      echo "</script>";
    }
    exit();
  }
?>	
 <?php 
 session_start();//登录系统开启一个session内容 
 $username=$_REQUEST["username"];//获取html中的用户名（通过post请求） 
 $password=$_REQUEST["password"];//获取html中的密码（通过post请求） 
 
 $con=mysqli_connect("localhost","root","","user_info");//连接mysql 数据库，账户名root ，密码root 
 if (!$con) { 
 die('数据库连接失败'.$mysqli_error()); 
 } 
 mysqli_select_db($con,"set name utf8");
	//use user_info数据库； 
 $dbusername=null; 
 $dbpassword=null; 
 $result=mysqli_query($con,"select * from user_info where username ='$username';");//查出对应用户名的信息 
 while ($row=mysqli_fetch_array($result)) {//while循环将$result中的结果找出来 
 $dbusername=$row["username"]; 
 $dbpassword=$row["password"]; 
 } 
 
 if ($dbusername!=$dbusername) {//用户名在数据库中不存在时跳回index.html界面 
 ?> 
 <script type="text/javascript"> 
 alert("用户名不存在"); 
 window.location.href="index.php"; 
 </script> 
 <?php 
 } 
 else { 
 if ($dbpassword!=$password){//当对应密码不对时跳回index.html界面 
 ?> 
 <script type="text/javascript"> 
 alert("密码错误"); 
 window.location.href="index.php"; 
 </script> 
 
	
 <?php 
 } 
 else { 
 $_SESSION["username"]!=$username; 
 $_SESSION["code"]=mt_rand(0, 100000);//给session附一个随机值，防止用户直接通过调用界面访问list.php 
 ?> 
 <script type="text/javascript"> 
 window.location.href="list.php"; 
 </script> 
 <?php 
 } 
 } 
 mysqli_close($con);//关闭数据库连接，如不关闭，下次连接时会出错 
 ?> 

	
</body> 
</html> 