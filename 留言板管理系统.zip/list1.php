
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>留言板</title>
<link rel="stylesheet" href="css/style.css">
	<style type="text/css">
.table{border-radius: 8px;border:1px }
			.main-container{
		width: 80%;
		margin:0 auto;
	}
	.bt{
		background:teal;
		height:40px;
		width:100px;
		position:relative;
		border:0px;
		border-radius:5px;
		color:white;
		-webkit-transform: rotate(0deg);
	}
body {
    background-image: url( "登录.jpg");
	background-attachment: fixed;
    background-repeat: no-repeat;
	left:0px; top:0px; width:100%; height:100%";
		
.style1 {
    font-family: "微软雅黑";
}
	
body,td,th {
	color: #00529F;
	font-family: "微软雅黑";
}
	
    body form {
	text-align: center;
}
	
    </style>
</head>

</style>
</head>
<body><script src="/demos/googlegg.js"></script>
<article class="zzsc"><br>
  <div class="main-container">
		<a href='list1.php'><button class="bt" id="b1"  >主  页</button></a>
		<a href='index.php'><button id="b2" class="bt" >登  录</button></a>
		<a href='register.html'><button id="b3" class="bt"  >注  册</button></a>
		<a href='alert.php'><button id="b4" class="bt"  >添加留言</button></a>
		<a href='alert.php'><button id="b5" class="bt"  >退出登录</button></a>
		
  </div>

</article>

<script src="js/jquery-2.1.1.min.js" type="text/javascript"></script>
<script  src="js/waterFloat.js"></script>
<script type="text/javascript">
	$(document).ready(function(){
		var b1 = $('#b1');
		var b2 = $('#b2');
		var b3 = $('#b3');
		var b4 = $('#b4'); 
		var b5 = $('#b5');
		
		var a1 = $('#a1');
		var a2 = $('#a2');
		var p1 = new waterFloat(b1,900,3,8);
		var p2 = new waterFloat(b2,700,3,8);
		var p3 = new waterFloat(b3,800,3,10);
		var p4 = new waterFloat(b4,900,3,8);
		var p5 = new waterFloat(b5,700,3,8);
		var p6 = new waterFloat(b6,800,3,10);
		var p7 = new waterFloat(b7,700,3,8);
		var p8 = new waterFloat(a1,700,3,8);
		var p9 = new waterFloat(a2,800,3,10);
	   });
</script>

<body>
<script src="/demos/googlegg.js"></script>
<center>
  <form name="form1" method="post" action="" >
    <p>
      <input name="search" type="search" value="" size="30" maxlength= "1000">
      <input name="submit" type="submit" id="submit" value="搜索"  />
    </p>
  </form>
 </p>
 </center>


	<?php 
include 'conn.php'; 
?> 


<?php
session_start();
session_unset();
session_destroy();

?>
<table width=511 height="103" border="0"   bordercolor=" #FFFFFF" align="center" cellpadding="5" cellspacing="1"  background="捕获.PNG" class="table" > 

<?php 
$pagesize=3;
$sqlstr="select * from message order by id";
$total=mysqli_query($conn,$sqlstr);
$totalNum=mysqli_num_rows($total);
$pagecount=ceil($totalNum/$pagesize);
(!isset($_GET['page']))?($page=1):$page=$_GET['page'];
($page<=$pagecount)?$page:($page=$pagecount);
$f_pageNum=$pagesize*($page-1);
$sqlstr1=$sqlstr." limit ".$f_pageNum.",".$pagesize;
$result=mysqli_query($conn,$sqlstr1);
  $x=1;
 

while ($row=mysqli_fetch_array($result)){ 
	
 
?> 



<tr > 
<td height="29" ><p>第<?=$x++?>楼 标题：<strong>
  <?=$row['title']?>
  </strong> 用户：<strong>
    <?=$row['user'] ?> </strong>
	<p>时间：<?=$row['lastdate']?></p>
	<p>内容：<strong>  <?php
	$str=$row['content'];
if(isset ($_POST["submit"])&& $_POST["submit"]=="搜索")
{
$a=substr_count($str,$_POST['search']);

echo str_ireplace($_POST['search'],'<span style="background:yellow"><font color="#FF0000">'.$_POST['search'].'</font></span>',$str);
echo  '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.$_POST['search']."出现" .$a."次";
}
else echo $str=$row['content'];

?>  
 <strong></p>
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  <a href='alert.php'>编辑</a>  |  <a href='alert.php'>删除</a></p></td> 
</tr> 
 
<?php }?> 
	
</table>
	<center>
	<ul id="menu"><?php
 echo "共".$totalNum."条留言&nbsp;&nbsp;";
echo "第".$page."页/共".$pagecount."页&nbsp;&nbsp;";
if($page!=1){
	echo "<li>";echo "<a href='?page=1'>首页</a>&nbsp;&nbsp;";echo "</li>";
	echo "<li>";echo "<a href='?page=".($page-1)."'>上一页</a>&nbsp;&nbsp;";echo "</li>";
	}else{
		echo "首页&nbsp;上一页&nbsp;&nbsp;";
	}
	if($page!=$pagecount){
		echo "<li>";echo "<a href='?page=".($page+1)."'>下一页</a>&nbsp;&nbsp;";echo "</li>";
		echo "<li>";echo "<a href='?page=".$pagecount."'>尾页</a>&nbsp;&nbsp;";echo "</li>";
		}else{
			echo "下一页&nbsp;尾页&nbsp;&nbsp;";
		}
?></ul>
	</center>



</body>
</html>